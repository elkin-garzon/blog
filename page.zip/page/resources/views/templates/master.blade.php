<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= Voyager::setting('title_site'); ?></title>
	<link rel="stylesheet" href="{{ 'css/style-page.css' }}">
</head>
	<body>
		<nav class="nav_principal">
			<?php
				foreach ($category as $category) { ?>
				<a href="{{$category->url}}">{{$category->slug}}</a>
			<?php } ?>
		</nav>
		<main class="content">
			@section('main')

			@show
		</main>
	</body>
	<script type="text/javascript" src="{{ 'js/page-analytics.js' }}"></script>
</html>