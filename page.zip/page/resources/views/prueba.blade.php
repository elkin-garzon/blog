<?php foreach ($users as $user) { ?>
	<a href="<?= $user->url; ?>" target="_blank">
		<figure>
			<img src="/<?= $user->photo; ?>" alt="">
			<figcaption>
				<h4><?= $user->name; ?></h4>
				<span><?= $user->description; ?></span>
			</figcaption>
		</figure>
	</a>
<?php } ?>

