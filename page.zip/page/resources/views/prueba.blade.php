<?php
	foreach ($banners as $banner) { ?>
	    <img src="/storage/{{ $banner->image }}" alt="{{ $banner->name }}">
<?php } ?>
