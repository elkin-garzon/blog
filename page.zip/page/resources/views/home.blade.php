<!-- EXTENDIENDO DE TEMPLATES-MASTER -->
@extends('templates.master')
	@section('main')
		<p>hola mundo</p>
	@endsection