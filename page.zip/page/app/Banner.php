<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Banner extends Model
{
   


    public function status(){
		return $this->belongsTo(Status::class);
	}
	public function bannerCategory(){
		return $this->belongsTo(BannerCategory::class);
	} 
}
