<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Banner extends Model
{
	/*RELACION CON ESTADOS*/
    public function status(){
		return $this->belongsTo(Status::class);
	}

	/*RELACION CON CATEGORIADE BANNER*/
    public function category(){
		return $this->belongsTo(BannerCategory::class);
	}	
}
