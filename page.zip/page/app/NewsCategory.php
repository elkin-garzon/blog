<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class NewsCategory extends Model
{
	/*RELACION CON ESTADOS*/
    public function status(){
		return $this->belongsTo(Status::class);
	} 
}
