<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class GalleryCategory extends Model
{
	/*RELACION CON ESTADOS*/
    public function status(){
		return $this->belongsTo(Status::class);
	}   
}
