<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class BannerCategory extends Model
{
    



    public function status(){
		return $this->belongsTo(Status::class);
	}
}
