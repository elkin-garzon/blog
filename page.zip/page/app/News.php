<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class News extends Model
{
    


    public function status(){
		return $this->belongsTo(Status::class);
	}  
    public function category(){
		return $this->belongsTo(NewsCategory::class);
	}
}
