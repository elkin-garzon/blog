<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Page extends Model
{

    public function categoryPage(){
		return $this->belongsTo(CategoryPage::class);
	} 

    public function status(){
		return $this->belongsTo(Status::class);
	} 
}
