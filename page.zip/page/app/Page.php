<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Page extends Model
{
	/*RELACION CON ESTADOS*/
    public function status(){
		return $this->belongsTo(Status::class);
	} 

	/*RELACION CON CATEGORIA DE PAGINAS*/
    public function category(){
		return $this->belongsTo(PageCategory::class);
	} 
}
