<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class GaleryPhoto extends Model
{
    public function category(){
		return $this->belongsTo(GaleryCategory::class);
	}
	
    public function album(){
		return $this->belongsTo(Album::class);
	} 
    public function status(){
		return $this->belongsTo(Status::class);
	}    
}
