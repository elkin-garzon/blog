<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class GalleryAlbum extends Model
{
	/*RELACION CON ESTADOS*/
    public function status(){
		return $this->belongsTo(Status::class);
	}

	/*RELACION CON CATEGORIA DE GALERIA*/
    public function category(){
		return $this->belongsTo(GalleryCategory::class);
	}   
}
