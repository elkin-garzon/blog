<?php
	foreach ($banners as $banner) { ?>
	    <img src="/storage/<?php echo e($banner->image); ?>" alt="<?php echo e($banner->name); ?>">
<?php } ?>
