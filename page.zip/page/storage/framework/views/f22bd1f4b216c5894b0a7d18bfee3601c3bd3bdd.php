<?php
	foreach ($banners as $banner) { ?>
	<a href="<?php echo e($banner->url); ?>"><?php echo e($banner->slug); ?></a>
<?php } ?>
