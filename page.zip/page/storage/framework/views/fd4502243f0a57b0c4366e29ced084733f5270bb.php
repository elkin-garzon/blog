<?php  $customization = Laralum\Customization\Models\Customization::first();  ?>
<link rel="icon" href="<?php echo e($customization->favicon); ?>">
<style>
    <?php if($customization->navbar_color): ?>
        .uk-navbar-container {
            background-color: <?php echo e($customization->navbar_color); ?> !important;
        }
    <?php endif; ?>
</style>
