<?php 
    $settings = \Laralum\Settings\Models\Settings::first();
    $packages = \Laralum\Laralum\Packages::all();
    $user = \Laralum\Users\Models\User::findOrFail(Auth::id());
 ?>
<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($settings->appname); ?></title>

        <meta charset="UTF-8">
        <meta name="description" content="<?php echo e($settings->description); ?>">
        <meta name="keywords" content="<?php echo e($settings->keywords); ?>">
        <meta name="author" content="<?php echo e($settings->author); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.20/css/uikit.min.css" integrity="sha256-k8IzyP/qSivihqS5ogICYMqmuacc6Op6HQrFMGRrdfw=" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://gitcdn.xyz/cdn/Laralum/Laralum/feecc1c067d7fb9dd7e16b8524b591eae28455a3/src/Assets/css/style.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.20/js/uikit.min.js" integrity="sha256-zg8+ewp+R2ncGBMQ3a+rhfLlef0gxfkG9zrBf+oSTQU=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.20/js/uikit-icons.min.js" integrity="sha256-iC7144xSYml8vsBsLNUxTvd3NAXNgnZrhv7ineC3t/o=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://gitcdn.xyz/cdn/Laralum/Laralum/feecc1c067d7fb9dd7e16b8524b591eae28455a3/src/Assets/css/notyf.min.css" />

        <!-- CSS Injection for packages -->
        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo \Laralum\Laralum\Injector::inject('style', $package); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo $__env->make('laralum::assets.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('css'); ?>

        <!-- Charts Assets -->
        <?php echo ConsoleTVs\Charts\Facades\Charts::assets(); ?>

    </head>
    <body>
        <div uk-sticky class="uk-navbar-container tm-navbar-container uk-active">
            <div class="uk-container uk-container-expand">
                <nav class="uk-navbar-container" uk-navbar>
                    <div class="uk-navbar-left">
                        <a id="sidebar_toggle" class="uk-navbar-toggle" uk-navbar-toggle-icon href="#"></a>
                        <a href="<?php echo e(route('laralum::index')); ?>" class="uk-navbar-item uk-logo"><?php echo e($settings->appname); ?></a>
                    </div>
                    <div class="uk-navbar-right uk-light">
                        <ul class="uk-navbar-nav">
                            <li class="uk-active">
                                <a id="navbar_lang" href="#"><span style="font-size:25px" class="ion-earth"></span></a>
                                <div sty uk-dropdown="pos: bottom-center; mode: click; offset: -17;">
                                    <ul class="uk-nav uk-navbar-dropdown-nav">
                                        <!-- User Injector -->
                                        <li class="uk-nav-header">Select Language</li>
                                        <?php $__currentLoopData = config('laralum.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(in_array($lang, config('localizer.allowed_langs')) && $lang != \Aitor24\Localizer\Facades\LocalizerFacade::getCurrentCode()): ?>
                                                <li>
                                                    <a href="<?php echo e(route("localizer::setLocale", ['lang' => $lang])); ?>">
                                                        <?php echo e(\Aitor24\Localizer\Facades\LocalizerFacade::getLanguage($lang)); ?>

                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </li>
                            <li class="uk-active">
                                <a id="navbar_name" href="#"><?php echo e(Auth::user()->name); ?> &nbsp;<span class="ion-ios-arrow-down"></span></a>
                                <div uk-dropdown="pos: bottom-right; mode: click; offset: -17;">
                                    <ul class="uk-nav uk-navbar-dropdown-nav">
                                        <!-- User Injector -->
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php  $items = \Laralum\Laralum\Injector::inject('user', $package)  ?>
                                            <?php if($items): ?>
                                                <?php 
                                                    $counter = 0;
                                                    foreach ($items as $item) {
                                                        $counter = $counter + (isset($item['counter']) ? $item['counter'] : 0);
                                                    }
                                                 ?>
                                                <li class="uk-nav-header"><?php echo e($package); ?> <?php if($counter): ?> <span class="uk-badge"><?php echo e($counter); ?></span> <?php endif; ?>
                                                </li>
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e($item['url']); ?>">
                                                            <?php echo e($item['text']); ?>

                                                            <?php 
                                                                $show = isset($item['counter']) ? $item['counter'] : false;
                                                             ?>
                                                            <?php if($show): ?> <span class="uk-badge"><?php echo e($show); ?></span> <?php endif; ?>
                                                        </a>

                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <li class="uk-nav-header"><?php echo app('translator')->getFromJson('laralum::general.actions'); ?></li>
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                <?php echo app('translator')->getFromJson('laralum::general.logout'); ?>
                                            </a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo e(csrf_field()); ?>

                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div id="sidebar" class="tm-sidebar-left uk-background-default">
            <center>
                <div class="user">
                    <img id="avatar" style="max-width:100px;max-height:100px;" class="uk-border-circle" src="<?php echo e($user->avatar()); ?>" />
                    <div class="uk-margin-top"></div>
                    <div id="name" class="uk-text-truncate"><?php echo e(Auth::user()->name); ?></div>
                    <div id="email" class="uk-text-truncate"><?php echo e(Auth::user()->email); ?></div>
                    <span id="status" data-enabled="true" data-online-text="<?php echo e(__('laralum::general.online')); ?>" data-away-text="<?php echo e(__('laralum::general.away')); ?>" data-interval="20000" class="uk-margin-top uk-label uk-label-success"></span>
                </div>
                <br />
            </center>
            <ul class="uk-nav uk-nav-default">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php  $menu = Laralum\Laralum\Packages::menu($package);  ?>
                    <?php if($menu and array_key_exists('items', $menu) ): ?>
                        <?php 
                            $generalPerm = false;
                            foreach ($menu['items'] as $item) {
                                if (! array_key_exists('permission', $item)) {
                                    $generalPerm = true;
                                } else {
                                    (! ($user->hasPermission($item['permission']) || $user->superAdmin())) ?: $generalPerm = true;
                                }
                            }
                         ?>
                        <?php if($generalPerm): ?>
                            <li class="uk-nav-header">
                                <?php echo e(ucfirst($package)); ?>

                            </li>
                        <?php endif; ?>
                        <?php $__currentLoopData = $menu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(array_key_exists('permission', $item)): ?>
                                <?php if($user->hasPermission($item['permission']) || $user->superAdmin()): ?>
                                    <li>
                                        <?php if((array_key_exists('text', $item) or array_key_exists('trans', $item)) and array_key_exists('link', $item)): ?>
                                            <a href="<?php echo e($item['link']); ?>">
                                                <?php echo e(array_key_exists('trans', $item) ? __($item['trans']) : $item['text']); ?>

                                            </a>
                                        <?php elseif((array_key_exists('text', $item) or array_key_exists('trans', $item)) and array_key_exists('route', $item)): ?>
                                            <a href="<?php echo e(route($item['route'])); ?>">
                                                <?php echo e(array_key_exists('trans', $item) ? __($item['trans']) : $item['text']); ?>

                                            </a>
                                        <?php endif; ?>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li>
                                    <?php if((array_key_exists('text', $item) or array_key_exists('trans', $item)) and array_key_exists('link', $item)): ?>
                                        <a href="<?php echo e($item['link']); ?>">
                                            <?php echo e(array_key_exists('trans', $item) ? __($item['trans']) : $item['text']); ?>

                                        </a>
                                    <?php elseif((array_key_exists('text', $item) or array_key_exists('trans', $item)) and array_key_exists('route', $item)): ?>
                                        <a href="<?php echo e(route($item['route'])); ?>">
                                            <?php echo e(array_key_exists('trans', $item) ? __($item['trans']) : $item['text']); ?>

                                        </a>
                                    <?php endif; ?>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(array_key_exists('menu', config('laralum'))): ?>
                    <?php $__currentLoopData = config('laralum.menu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="uk-nav-header">
                            <?php echo e($custom_menu['title']); ?>

                        </li>
                        <?php $__currentLoopData = $custom_menu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(array_key_exists('text', $custom_item) or array_key_exists('trans', $custom_item)): ?>
                                <?php if(array_key_exists('permission', $custom_item)): ?>
                                    <?php if($user->hasPermission($custom_item['permission']) || $user->superAdmin()): ?>
                                        <li>
                                            <?php if((array_key_exists('text', $custom_item) or array_key_exists('trans', $custom_item)) and array_key_exists('link', $custom_item)): ?>
                                                <a href="<?php echo e($custom_item['link']); ?>">
                                                    <?php echo e(array_key_exists('trans', $custom_item) ? __($custom_item['trans']) : $custom_item['text']); ?>

                                                </a>
                                            <?php elseif((array_key_exists('text', $custom_item) or array_key_exists('trans', $custom_item)) and array_key_exists('route', $custom_item)): ?>
                                                <a href="<?php echo e(route($custom_item['route'])); ?>">
                                                    <?php echo e(array_key_exists('trans', $custom_item) ? __($custom_item['trans']) : $custom_item['text']); ?>

                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li>
                                        <?php if((array_key_exists('text', $custom_item) or array_key_exists('trans', $custom_item)) and array_key_exists('link', $custom_item)): ?>
                                            <a href="<?php echo e($custom_item['link']); ?>">
                                                <?php echo e(array_key_exists('trans', $custom_item) ? __($custom_item['trans']) : $custom_item['text']); ?>

                                            </a>
                                        <?php elseif((array_key_exists('text', $custom_item) or array_key_exists('trans', $custom_item)) and array_key_exists('route', $custom_item)): ?>
                                            <a href="<?php echo e(route($custom_item['route'])); ?>">
                                                <?php echo e(array_key_exists('trans', $custom_item) ? __($custom_item['trans']) : $custom_item['text']); ?>

                                            </a>
                                        <?php endif; ?>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
        <div class="content-padder content-background">
            <div class="uk-section-small uk-section-default header">
                <div class="uk-container uk-container-large">
                    <h1><span class="<?php echo $__env->yieldContent('icon'); ?>"></span> <?php echo $__env->yieldContent('title'); ?></h1>
                    <p>
                        <?php echo $__env->yieldContent('subtitle'); ?>
                    </p>
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </div>
            </div>
            <div class="uk-section-small">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.transit/0.9.12/jquery.transit.min.js" integrity="sha256-rqEXy4JTnKZom8mLVQpvni3QHbynfjPmPxQVsPZgmJY=" crossorigin="anonymous"></script>
        <script src="https://gitcdn.xyz/cdn/Laralum/Laralum/feecc1c067d7fb9dd7e16b8524b591eae28455a3/src/Assets/js/script.js"></script>
        <script src="https://gitcdn.xyz/cdn/Laralum/Laralum/feecc1c067d7fb9dd7e16b8524b591eae28455a3/src/Assets/js/status.js"></script>
        <script src="https://gitcdn.xyz/cdn/Laralum/Laralum/feecc1c067d7fb9dd7e16b8524b591eae28455a3/src/Assets/js/notyf.min.js"></script>

        <?php echo $__env->make('laralum::assets.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('js'); ?>

        <!-- JS Injection for packages -->
        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo \Laralum\Laralum\Injector::inject('script', $package); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <script>
            $(function() {
                function resize_navbar()
                {
                    if ($( window ).width() < 960) {
                        $('#navbar_name').html("<span style='font-size:25px' class='ion-person'></span>");
                    } else {
                        $('#navbar_name').html("<?php echo e(Auth::user()->name); ?>");
                    }
                }
                resize_navbar();
                $( window ).resize(function() {
            		resize_navbar();
            	});
            })
        </script>
    </body>
</html>
