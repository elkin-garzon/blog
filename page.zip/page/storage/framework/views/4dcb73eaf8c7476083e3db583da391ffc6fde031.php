<?php $__env->startSection('icon', 'ion-unlocked'); ?>
<?php $__env->startSection('title', __('laralum_roles::general.role_permissions')); ?>
<?php $__env->startSection('subtitle', __('laralum_roles::general.permissions_desc', ['id' => $role->id, 'total' => $permissions->count()])); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_roles::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::roles.index')); ?>"><?php echo app('translator')->getFromJson('laralum_roles::general.role_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_roles::general.role_permissions'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_roles::general.available_permissions'); ?>
                    </div>
                    <div class="uk-card-body">
                        <form class="uk-form-stacked" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php if(isset($method)): ?> <?php echo e(method_field($method)); ?> <?php endif; ?>
                            <fieldset class="uk-fieldset">
                                <div uk-grid>
                                    <div class="uk-width-1-1">
                                        <div class="uk-button-group">
                                            <a href="#" id="checkAll" class="uk-button uk-button-default uk-button-small">Check All</a>
                                            <a href="#" id="uncheckAll" class="uk-button uk-button-default uk-button-small">Unckeck All</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="uk-width-1-1@m uk-width-1-3@l">
                                                <label><input class="uk-checkbox perm-checkbox" name="<?php echo e($permission->id); ?>" type="checkbox"  <?php if($role->hasPermission($permission)): ?> checked <?php endif; ?>> <?php echo e($permission->name); ?></label>
                                                <div class="uk-text-meta">
                                                    <?php echo e($permission->description); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                                   <div class="uk-margin">
                                       <a href="<?php echo e(route('laralum::roles.index')); ?>" class="uk-button uk-button-default"> <?php echo app('translator')->getFromJson('laralum_roles::general.cancel'); ?></a>
                                       <div class="uk-align-right">
                                           <button type="submit" class="uk-button uk-button-primary">
                                               <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_roles::general.submit'); ?>
                                           </button>
                                       </div>
                                   </div>
                               </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $('#checkAll').click(function() {
            $('.perm-checkbox').each(function() {
                $(this).prop('checked', true);
            })
        });
        $('#uncheckAll').click(function() {
            $('.perm-checkbox').each(function() {
                $(this).prop('checked', false);
            })
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>