<?php 
    $settings = \Laralum\Blog\Models\Settings::first();
 ?>
<?php $__env->startSection('icon', 'ion-plus-round'); ?>
<?php $__env->startSection('title', __('laralum_blog::general.create_post')); ?>
<?php $__env->startSection('subtitle', __('laralum_blog::general.create_post_desc')); ?>
<?php $__env->startSection('css'); ?>
    <?php if($settings->text_editor == 'wysiwyg'): ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.5.5/tinymce.min.js"></script>
        <script>
            tinymce.init({ selector:'textarea',   plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table contextmenu paste code'
            ] });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::blog.categories.index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_blog::general.create_post'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-1@s uk-width-1-5@l"></div>
            <div class="uk-width-1-1@s uk-width-3-5@l">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo e(__('laralum_blog::general.create_post')); ?>

                    </div>
                    <div class="uk-card-body">
                        <form class="uk-form-stacked" method="POST" action="<?php echo e(route('laralum::blog.posts.store')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <fieldset class="uk-fieldset">
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.title'); ?></label>
                                    <div class="uk-form-controls">
                                        <input value="<?php echo e(old('title')); ?>" name="title" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_blog::general.title'); ?>">
                                    </div>
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.image_url'); ?></label>
                                    <div class="uk-form-controls">
                                        <input value="<?php echo e(old('image')); ?>" name="image" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_blog::general.image_url_ph'); ?>">
                                    </div>
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.description'); ?></label>
                                    <div class="uk-form-controls">
                                        <input value="<?php echo e(old('description')); ?>" name="description" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_blog::general.description'); ?>">
                                    </div>
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.category'); ?></label>
                                    <div class="uk-form-controls">
                                        <select required name="category" class="uk-select">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.content'); ?></label>
                                    <?php if($settings->text_editor == 'wysiwyg'): ?>
                                        <textarea name="content" rows="15"><?php echo e(old('content')); ?></textarea>
                                    <?php else: ?>
                                        <?php 
                                        $text = old('content');
                                        if ($settings->text_editor == 'markdown') {
                                            $converter = new League\HTMLToMarkdown\HtmlConverter();
                                            $text = $converter->convert($text);
                                        }
                                         ?>
                                        <textarea name="content" class="uk-textarea" rows="15" placeholder="<?php echo e(__('laralum_blog::general.content')); ?>"><?php echo e($text); ?></textarea>
                                        <?php if($settings->text_editor == 'markdown'): ?>
                                            <i><?php echo app('translator')->getFromJson('laralum_blog::general.markdown'); ?></i>
                                        <?php else: ?>
                                            <i><?php echo app('translator')->getFromJson('laralum_blog::general.plain_text'); ?></i>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>

                                <div class="uk-margin">
                                    <button type="submit" class="uk-button uk-button-primary uk-align-right">
                                        <span class="ion-forward"></span>&nbsp; <?php echo e(__('laralum_blog::general.create_post')); ?>

                                    </button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-1-5@l"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>