<?php $__env->startSection('icon', 'ion-settings'); ?>
<?php $__env->startSection('title', __('laralum_settings::general.title')); ?>
<?php $__env->startSection('subtitle', __('laralum_settings::general.subtitle')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_settings::general.home'); ?></a></li>
        <li><span href=""><?php echo app('translator')->getFromJson('laralum_settings::general.title'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php 
        $p = isset($_GET['p']) ? $_GET['p'] : 'Settings';
        $p = strtolower($p);
     ?>
    <div class="uk-container uk-container-large">
        <div uk-grid class="uk-grid-small">
            <div class="uk-width-1-1@s uk-width-2-5@m uk-width-1-3@l uk-width-1-5@xl">
                <div class="uk-card uk-card-default" uk-sticky="media: 640; bottom: true; offset: 120;">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_settings::general.modules_available'); ?>
                    </div>
                    <div class="uk-card-body">
                        <ul class="uk-tab-left" uk-tab="connect: #settings-content; media: ">
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package => $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php if(strtolower($package) == $p): ?> uk-active <?php endif; ?>">
                                    <a href="#<?php echo e($package); ?>">
                                        <?php echo e($package); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-3-5@m uk-width-2-3@l uk-width-4-5@xl">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_settings::general.modules_settings'); ?>
                    </div>
                    <div class="uk-card-body">
                        <ul id="settings-content" class="uk-switcher">
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package => $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo $view; ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $(window).resize(function() {
            if ($(window).width() < 1382) {
                $('.uk-form-horizontal').each(function() {
                    $(this).removeClass('uk-form-horizontal');
                    $(this).addClass('uk-form-stacked');
                });
            } else {
                $('.uk-form-stacked').each(function() {
                    $(this).removeClass('uk-form-stacked');
                    $(this).addClass('uk-form-horizontal');
                });
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>