<?php $__env->startSection('icon', 'ion-plus-round'); ?>
<?php $__env->startSection('title', __('laralum_permissions::general.create_permission')); ?>
<?php $__env->startSection('subtitle', __('laralum_permissions::general.create_permission_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_permissions::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::permissions.index')); ?>"><?php echo app('translator')->getFromJson('laralum_permissions::general.permission_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_permissions::general.create_permission'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('laralum_permissions::form', [
        'title' =>  __('laralum_permissions::general.create_permission'),
        'action' => route('laralum::permissions.store'),
        'button' => __('laralum_permissions::general.create'),
        'cancel' => route('laralum::permissions.index')
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>