<?php 
    $settings = \Laralum\Blog\Models\Settings::first();
 ?>
<div uk-grid>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \Laralum\Blog\Models\Settings::class)): ?>
    <div class="uk-width-1-1@s uk-width-1-5@l"></div>
    <div class="uk-width-1-1@s uk-width-3-5@l">
        <form class="uk-form-horizontal" method="POST" action="<?php echo e(route('laralum::blog.settings.update')); ?>">
            <?php echo e(csrf_field()); ?>

            <fieldset class="uk-fieldset">

            <div class="uk-margin">
                <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.text_editor'); ?></label>
                <div class="uk-form-controls">
                    <select name="text_editor" class="uk-select">
                        <option value="" <?php if(!$settings->text_editor): ?> selected <?php endif; ?> disabled><?php echo app('translator')->getFromJson('laralum_blog::general.select_editor'); ?></option>
                        <option <?php if($settings->text_editor == 'plain-text'): ?> selected <?php endif; ?> value="plain-text"><?php echo app('translator')->getFromJson('laralum_blog::general.plain_text'); ?></option>
                        <option <?php if($settings->text_editor == 'markdown'): ?> selected <?php endif; ?> value="markdown"><?php echo app('translator')->getFromJson('laralum_blog::general.markdown'); ?></option>
                        <option <?php if($settings->text_editor == 'wysiwyg'): ?> selected <?php endif; ?> value="wysiwyg"><?php echo app('translator')->getFromJson('laralum_blog::general.wysiwyg'); ?></option>
                    </select>
                    <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_blog::general.text_editor_desc'); ?></small>
                </div>
            </div>

            <div class="uk-margin">
                <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.public_url'); ?></label>
                <div class="uk-form-controls">
                    <input value="<?php echo e(old('navbar_color', $settings->public_url)); ?>" name="public_url" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_blog::general.public_url'); ?>">
                    <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_blog::general.public_url'); ?></small>
                </div>
            </div>

                <div class="uk-margin uk-align-right">
                    <button type="submit" class="uk-button uk-button-primary">
                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_blog::general.save_settings'); ?>
                    </button>
                </div>

            </fieldset>
        </form>
    </div>
    <div class="uk-width-1-1@s uk-width-1-5@l"></div>
    <?php else: ?>
        <div class="uk-width-1-1">
            <div class="content-background">
                <div class="uk-section uk-section-small uk-section-default">
                    <div class="uk-container uk-text-center">
                        <h3>
                            <span class="ion-minus-circled"></span>
                            <?php echo app('translator')->getFromJson('laralum_blog::general.unauthorized_action'); ?>
                        </h3>
                        <p>
                            <?php echo app('translator')->getFromJson('laralum_blog::general.unauthorized_desc'); ?>
                        </p>
                        <p class="uk-text-meta">
                            <?php echo app('translator')->getFromJson('laralum_blog::general.contact_webmaster'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
