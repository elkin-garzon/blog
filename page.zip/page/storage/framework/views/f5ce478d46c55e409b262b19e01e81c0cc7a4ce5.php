<?php $__env->startSection('icon', 'ion-key'); ?>
<?php $__env->startSection('title', __('laralum_permissions::general.permission_list')); ?>
<?php $__env->startSection('subtitle', __('laralum_permissions::general.permissions_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_permissions::general.home'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_permissions::general.permission_list'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid class="uk-child-width-1-1">
            <div>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_permissions::general.permission_list'); ?>
                    </div>
                    <div class="uk-card-body">
                        <div class="uk-overflow-auto">
                            <table class="uk-table uk-table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo app('translator')->getFromJson('laralum_permissions::general.name'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_permissions::general.slug'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_permissions::general.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($permission->id); ?></td>
                                            <td><?php echo e($permission->name); ?></td>
                                            <td><?php echo e($permission->slug); ?></td>
                                            <td class="uk-table-shrink">
                                                <div class="uk-button-group">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $permission)): ?>
                                                        <a href="<?php echo e(route('laralum::permissions.edit', ['permission' => $permission->id])); ?>" class="uk-button uk-button-small uk-button-default">
                                                            <?php echo app('translator')->getFromJson('laralum_permissions::general.edit'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_permissions::general.edit'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $permission)): ?>
                                                        <a href="<?php echo e(route('laralum::permissions.destroy.confirm', ['permission' => $permission->id])); ?>" class="uk-button uk-button-small uk-button-danger">
                                                            <?php echo app('translator')->getFromJson('laralum_permissions::general.delete'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_permissions::general.delete'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo $__env->make('laralum::layouts.pagination', ['paginator' => $permissions], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>