<?php  $delay = 0; $increment = 150;  ?>
<script>
    var notyf = new Notyf({ delay: 5000 });
    <?php if(Session::has('error')): ?>
        notyf.alert("<?php echo e(Session::get('error')); ?>");
        <?php  $delay += $increment;  ?>
    <?php elseif(Session::has('success')): ?>
        notyf.confirm("<?php echo e(Session::get('success')); ?>");
        <?php  $delay += $increment;  ?>
    <?php endif; ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        setTimeout(function() {
            notyf.alert("<?php echo e($error); ?>");
        }, <?php echo e($delay); ?>);
        <?php  $delay += $increment;  ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
