<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php echo app('translator')->getFromJson('laralum_blog::general.view_post'); ?> - <?php echo e(Laralum\Settings\Models\Settings::first()->appname); ?></title>
        <style>
            .hidden {
                display: none;
            }
        </style>
    </head>
    <body>
        <h1><?php echo app('translator')->getFromJson('laralum_blog::general.view_post'); ?></h1>
        <?php if(Session::has('success')): ?>
            <hr>
            <p style="color:green">
                <?php echo e(Session::get('success')); ?>

            </p>
            <hr>
        <?php endif; ?>
        <?php if(Session::has('info')): ?>
            <hr>
            <p style="color:blue">
                <?php echo e(Session::get('info')); ?>

            </p>
            <hr>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <hr>
            <p style="color:red">
                <?php echo e(Session::get('error')); ?>

            </p>
            <hr>
        <?php endif; ?>
        <?php if(count($errors->all())): ?>
            <hr>
            <p style="color:red">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br/><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <hr>
        <?php endif; ?>

        <img src="<?php echo e($post->image); ?>" alt="">
        <h1><?php echo e($post->title); ?></h1>
        <p><?php echo app('translator')->getFromJson('laralum_blog::general.written_by', ['username' => $post->user->name, 'time_ago' => $post->created_at->diffForHumans(), 'cat' => $post->category->title]); ?></p>
        <p><?php echo $post->content; ?></p>
        <br>
        <div class="uk-grid-small uk-child-width-1-1" uk-grid>
            <span>
                <a href="#comments"><?php echo e(trans_choice('laralum_blog::general.comments_choice', $post->comments->count(), ['num' => $post->comments->count()])); ?></a>
            </span>
        </div>
        <br><br><br>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('publicAccess', \Laralum\Blog\Models\Comment::class)): ?>
            <div id="comments">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title"><?php if($post->comments->count()): ?> <?php echo app('translator')->getFromJson('laralum_blog::general.comments'); ?> <?php else: ?> <?php echo app('translator')->getFromJson('laralum_blog::general.no_comments_yet'); ?> <?php endif; ?></h3>
                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $comment)): ?>
                            <article class="uk-comment uk-comment-primary">
                                <header class="uk-comment-header uk-grid-medium uk-flex-middle" uk-grid>

                                    <div class="uk-width-auto">
                                        <img class="uk-comment-avatar uk-border-circle" src="<?php echo e($comment->user->avatar()); ?>" width="80" height="80" alt="">
                                    </div>
                                    <div class="uk-width-expand">
                                        <h4 class="uk-comment-title uk-margin-remove"><span><?php echo e($comment->user->name); ?></span></h4>
                                        <ul class="uk-comment-meta uk-subnav uk-subnav-divider uk-margin-remove-top">
                                            <li><span><?php echo e($comment->created_at->diffForHumans()); ?></span></li>
                                        </ul>
                                    </div>
                                </header>
                                <div class="uk-comment-body">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('publicDelete', $comment)): ?>
                                        <form action="<?php echo e(route('laralum_public::blog.comments.destroy',['category' => $post->category->id, 'post' => $post->id, 'comment' => $comment->id ])); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" name="button"><?php echo app('translator')->getFromJson('laralum_blog::general.delete'); ?></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('publicUpdate', $comment)): ?>
                                        <button class="uk-button uk-button-text uk-align-right edit-comment-button" data-comment="<?php echo e($comment->comment); ?>" data-url="<?php echo e(route('laralum_public::blog.comments.update',['category' => $post->category->id, 'post' => $post->id, 'comment' => $comment->id ])); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.edit'); ?></button>
                                    <?php endif; ?>
                                    <p class="comment"><?php echo e($comment->comment); ?></p>
                                </div>
                            </article>
                            <br>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('publicCreate', \Laralum\Blog\Models\Comment::class)): ?>
                                <img src="<?php echo e(\Laralum\Users\Models\User::findOrFail(Auth::id())->avatar()); ?>" width="80" height="80" alt="">
                                <h4><span><?php echo e(\Laralum\Users\Models\User::findOrFail(Auth::id())->name); ?></span></h4>
                        <div>
                            <form method="POST" action="<?php echo e(route('laralum_public::blog.comments.store', ['post' => $post->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <textarea name="comment" class="uk-textarea" rows="8" placeholder="<?php echo e(__('laralum_blog::general.add_a_comment')); ?>"><?php echo e(old('comment')); ?></textarea>
                                <button type="submit"><?php echo app('translator')->getFromJson('laralum_blog::general.submit'); ?></button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <form class="hidden" id="edit-comment-form" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>

                        <textarea name="comment" class="uk-textarea" id="comment-textarea" rows="8" placeholder="<?php echo e(__('laralum_blog::general.edit_a_comment')); ?>"><?php echo e(old('comment')); ?></textarea>
                        <button type="submit" class="uk-button uk-button-primary"><?php echo app('translator')->getFromJson('laralum_blog::general.submit'); ?></button>
            </form>
        <?php endif; ?>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
        <script>
            $(function() {
                $('.edit-comment-button').click(function() {
                    $('.edit-comment-button').prop('disabled', false);
                    $(this).attr('disabled', 'disabled');
                    var url = $(this).data('url');
                    var comment = $(this).data('comment');
                    $('#comment-textarea').html(comment);
                    var form = $('#edit-comment-form').html();
                    $('.edit-comment-form').hide();
                    $('.comment').removeClass("hidden"); 
                    $(this).next().html('<form class="uk-form-stacked edit-comment-form uk-animation-scale-up" id="edit-comment-form" action="' + url + '" method="POST">' + form + '</form><p class="comment hidden">'+comment+'</p>');
                });
            });
        </script>
    </body>
</html>
