<?php 
    $customization = \Laralum\Customization\Models\Customization::first();
 ?>
<div uk-grid>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', \Laralum\Customization\Models\Customization::class)): ?>
    <div class="uk-width-1-1@s uk-width-1-5@l"></div>
    <div class="uk-width-1-1@s uk-width-3-5@l">
        <form class="uk-form-horizontal" method="POST" action="<?php echo e(route('laralum::customization.index.update')); ?>">
            <?php echo e(csrf_field()); ?>

            <fieldset class="uk-fieldset">

                <!--
                <div class="uk-margin">
                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_customization::general.text_color'); ?></label>
                    <input value="<?php echo e(old('color', $customization->color ? $customization->color : '')); ?>" name="color" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_customization::general.text_color_ph'); ?>">
                    <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_customization::general.text_color_hp'); ?></small>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_customization::general.back_color'); ?></label>
                    <input value="<?php echo e(old('background_color', $customization->background_color ? $customization->background_color : '')); ?>" name="background_color" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_customization::general.back_color_ph'); ?>">
                    <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_customization::general.back_color_hp'); ?></small>
                </div>
                -->

                <div class="uk-margin">
                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_customization::general.navbar_color'); ?></label>
                    <div class="uk-form-controls">
                        <input value="<?php echo e(old('navbar_color', $customization->navbar_color ? $customization->navbar_color : '')); ?>" name="navbar_color" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_customization::general.navbar_color_ph'); ?>">
                        <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_customization::general.navbar_color_hp'); ?></small>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_customization::general.favicon'); ?></label>
                    <div class="uk-form-controls">
                        <input value="<?php echo e(old('favicon', $customization->favicon ? $customization->favicon : '')); ?>" name="favicon" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_customization::general.favicon_ph'); ?>">
                        <small class="uk-text-meta"><?php echo app('translator')->getFromJson('laralum_customization::general.favicon_hp'); ?></small>
                    </div>
                </div>

                <div class="uk-margin uk-align-right">
                    <button type="submit" class="uk-button uk-button-primary">
                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_customization::general.save'); ?>
                    </button>
                </div>

            </fieldset>
        </form>
    </div>
    <div class="uk-width-1-1@s uk-width-1-5@l"></div>
    <?php else: ?>
        <div class="uk-width-1-1@s">
        <div class="content-padder content-background">
            <div class="uk-section-small uk-section-default header">
                <div class="uk-container uk-container-large">
                    <h3><span class="ion-minus-circled"></span> <?php echo app('translator')->getFromJson('laralum_customization::general.unauthorized_action'); ?></h3>
                    <p>
                        <?php echo app('translator')->getFromJson('laralum_customization::general.unauthorized_desc'); ?>
                    </p>
                    <p class="uk-text-meta">
                        <?php echo app('translator')->getFromJson('laralum_customization::general.contact_webmaster'); ?>
                    </p>
                </div>
            </div>
        </div>
        </div>
    <?php endif; ?>
</div>
