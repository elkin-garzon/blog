<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= Voyager::setting('title_site'); ?></title>
	<link rel="stylesheet" href="<?php echo e('css/style-page.css'); ?>">
</head>
	<body>
		<nav class="nav_principal">
			<?php
				foreach ($category as $category) { ?>
				<a href="<?php echo e($category->url); ?>"><?php echo e($category->slug); ?></a>
			<?php } ?>
		</nav>
		<main class="content">
			<?php $__env->startSection('main'); ?>

			<?php echo $__env->yieldSection(); ?>
		</main>
	</body>
	<script type="text/javascript" src="<?php echo e('js/page-analytics.js'); ?>"></script>
</html>