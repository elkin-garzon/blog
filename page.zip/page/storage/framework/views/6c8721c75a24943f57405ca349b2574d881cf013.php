<?php $__env->startSection('icon', 'ion-stop'); ?>
<?php $__env->startSection('title', __('laralum_blog::general.category_posts')); ?>
<?php $__env->startSection('subtitle', __('laralum_blog::general.category_desc', ['id' => $category->id])); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::blog.categories.index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_blog::general.category_posts'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-large">
    <div class="uk-child-width-1-2@m uk-child-width-1-1@s uk-grid-match" uk-grid>
        <?php if($posts->count()): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="uk-margin-remove">
                    <div class="uk-card uk-card-default uk-margin-medium-bottom">
                        <div class="uk-card-media-top">
                            <img src="<?php echo e($post->image); ?>" alt="">
                        </div>
                        <div class="uk-card-header">
                            <div class="uk-grid-small uk-flex-middle" uk-grid>
                                <div class="uk-width-expand">
                                    <h3 class="uk-card-title uk-margin-remove-bottom"><?php echo e($post->title); ?></h3>
                                    <p class="uk-text-meta uk-margin-remove-top"><time><?php echo e($post->created_at->diffForHumans()); ?></time></p>
                                </div>
                            </div>
                        </div>
                        <div class="uk-card-body">
                            <p><?php echo e($post->description); ?></p>
                        </div>
                        <div class="uk-card-footer">
                            <a href="<?php echo e(route('laralum::blog.posts.show', ['post' => $post->id])); ?>" class="uk-button uk-button-text"><?php echo app('translator')->getFromJson('laralum_blog::general.view_post'); ?></a>
                            <span class="uk-align-right"><?php echo e($post->comments->count()); ?> <i style="font-size:20px;" class="icon ion-chatboxes"></i></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default uk-card-body">
                    <div uk-alert>
                        <p><?php echo app('translator')->getFromJson('laralum_blog::general.no_posts_yet'); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('laralum::layouts.pagination', ['paginator' => $posts], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>