<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php echo app('translator')->getFromJson('laralum_blog::general.category_posts'); ?> - <?php echo e(Laralum\Settings\Models\Settings::first()->appname); ?></title>
    </head>
    <body>
        <h1><?php echo app('translator')->getFromJson('laralum_blog::general.category_posts'); ?></h1>
        <div>
            <?php if($posts->count()): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <img src="<?php echo e($post->image); ?>" alt="">
                        <h3><?php echo e($post->title); ?></h3>
                        <p><time datetime="2016-04-01T19:00"><?php echo e($post->created_at->diffForHumans()); ?></time></p>
                        <p><?php echo e($post->description); ?></p>
                        <a href="<?php echo e(route('laralum_public::blog.posts.show', ['post' => $post->id])); ?>" ><?php echo app('translator')->getFromJson('laralum_blog::general.view_post'); ?></a>
                        <span><?php echo e(trans_choice('laralum_blog::general.comments_choice', $post->comments->count(), ['num' => $post->comments->count()])); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($posts->links()); ?>

            <?php else: ?>
                <div class="uk-width-1-1">
                    <div class="uk-card uk-card-default uk-card-body">
                        <div uk-alert>
                            <p><?php echo app('translator')->getFromJson('laralum_blog::general.no_posts_yet'); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </body>
</html>
