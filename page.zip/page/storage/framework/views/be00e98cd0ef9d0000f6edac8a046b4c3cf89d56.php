<?php $__env->startSection('icon', 'ion-alert-circled'); ?>
<?php $__env->startSection('title', trans('laralum::general.confirmation_page')); ?>
<?php $__env->startSection('subtitle', trans('laralum::general.perform_action')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum::general.home'); ?></a></li>
        <li><span href=""><?php echo app('translator')->getFromJson('laralum::general.confirmation_page'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
            <div class="uk-width-1-1@s uk-width-3-5@l uk-width-1-3@xl">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum::general.confirmation_page'); ?>
                    </div>
                    <div class="uk-card-body">

                            <h4><?php if(isset($message)): ?> <?php echo e($message); ?> <?php else: ?> <?php echo app('translator')->getFromJson('laralum::general.confirmation_proceed'); ?> <?php endif; ?></h4>
                            <p><?php if(isset($description)): ?> <?php echo e($description); ?> <?php else: ?> <?php echo app('translator')->getFromJson('laralum::general.confirmation_info'); ?> <?php endif; ?></p>
                            <br>
                        <form class="uk-form-stacked"  <?php if(isset($action)): ?> action="<?php echo e($action); ?>" <?php endif; ?> method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php if(isset($method)): ?> <?php echo e(method_field($method)); ?> <?php endif; ?>
                                <div class="uk-margin">
                                    <a href="<?php echo e(URL::previous()); ?>" class="uk-button uk-button-default uk-align-left"><?php echo app('translator')->getFromJson('laralum::general.take_me_back'); ?></a>
                                    <button type="submit" class="uk-button uk-button-primary uk-align-right">
                                        <span class="ion-forward"></span>&nbsp; <?php if(isset($button)): ?> <?php echo e($button); ?> <?php else: ?> <?php echo app('translator')->getFromJson('laralum::general.proceed'); ?> <?php endif; ?>
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>