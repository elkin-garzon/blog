<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?> - <?php echo e(Laralum\Settings\Models\Settings::first()->appname); ?></title>
    </head>
    <body>
        <h1><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></h1>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo app('translator')->getFromJson('laralum_blog::general.name'); ?></th>
                    <th><?php echo app('translator')->getFromJson('laralum_blog::general.actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                                <a href="<?php echo e(route('laralum_public::blog.categories.show', ['category' => $category->id])); ?>">
                                    <?php echo app('translator')->getFromJson('laralum_blog::general.view'); ?>
                                </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($categories->links()); ?>

    </body>
</html>
