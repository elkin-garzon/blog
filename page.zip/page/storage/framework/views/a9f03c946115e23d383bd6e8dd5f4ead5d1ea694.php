<?php $__env->startSection('icon', 'ion-person-stalker'); ?>
<?php $__env->startSection('title', __('laralum_users::general.user_list')); ?>
<?php $__env->startSection('subtitle', __('laralum_users::general.users_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_users::general.home'); ?></a></li>
        <li><span href=""><?php echo app('translator')->getFromJson('laralum_users::general.user_list'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid class="uk-child-width-1-1">
            <div>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_users::general.user_list'); ?>
                    </div>
                    <div class="uk-card-body">
                        <div class="uk-overflow-auto">
                            <table class="uk-table uk-table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo app('translator')->getFromJson('laralum_users::general.name'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_users::general.email'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_users::general.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td class="uk-table-shrink">
                                                <div class="uk-button-group">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles', $user)): ?>
                                                        <a href="<?php echo e(route('laralum::users.roles.manage', ['id' => $user->id])); ?>" class="uk-button uk-button-small uk-button-default">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.roles'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.roles'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
                                                        <a href="<?php echo e(route('laralum::users.edit', ['id' => $user->id])); ?>" class="uk-button uk-button-small uk-button-default <?php if($user->id == Auth::id()): ?> uk-disabled <?php endif; ?>">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.edit'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.edit'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                                                        <a href="<?php echo e(route('laralum::users.destroy.confirm', ['user' => $user->id])); ?>" class="uk-button uk-button-small uk-button-danger <?php if($user->id == Auth::id()): ?> uk-disabled <?php endif; ?>">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.delete'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_users::general.delete'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo $__env->make('laralum::layouts.pagination', ['paginator' => $users], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>