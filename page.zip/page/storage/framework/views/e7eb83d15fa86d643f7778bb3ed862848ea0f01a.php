<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.js')); ?>"></script>  
