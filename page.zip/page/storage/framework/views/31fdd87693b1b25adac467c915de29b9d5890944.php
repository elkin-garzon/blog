<?php $__env->startSection('icon', 'ion-grid'); ?>
<?php $__env->startSection('title', __('laralum_blog::general.category_list')); ?>
<?php $__env->startSection('subtitle', __('laralum_blog::general.categories_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.home'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-5@l uk-width-1-1@m"></div>
            <div class="uk-width-3-5@l uk-width-1-1@m">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?>
                    </div>
                    <div class="uk-card-body">
                        <div class="uk-overflow-auto">
                            <table class="uk-table uk-table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo app('translator')->getFromJson('laralum_blog::general.name'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_blog::general.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td class="uk-table-shrink">
                                                <div class="uk-button-group">
                                                    <a class="uk-button uk-button-default uk-button-small" href="<?php echo e(route('laralum::blog.categories.show', ['id' => $category->id])); ?>">
                                                        <?php echo app('translator')->getFromJson('laralum_blog::general.view'); ?>
                                                    </a>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $category)): ?>
                                                        <a class="uk-button uk-button-default uk-button-small" href="<?php echo e(route('laralum::blog.categories.edit', ['id' => $category->id])); ?>">
                                                            <?php echo app('translator')->getFromJson('laralum_blog::general.edit'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-default uk-button-small">
                                                            <?php echo app('translator')->getFromJson('laralum_blog::general.update'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $category)): ?>
                                                        <a class="uk-button uk-button-small uk-button-danger" href="<?php echo e(route('laralum::blog.categories.destroy.confirm', ['id' => $category->id])); ?>">
                                                            <?php echo app('translator')->getFromJson('laralum_blog::general.delete'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled class="uk-button uk-button-small uk-button-danger">
                                                            <?php echo app('translator')->getFromJson('laralum_blog::general.delete'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo $__env->make('laralum::layouts.pagination', ['paginator' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-5@l uk-width-1-1@m"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>