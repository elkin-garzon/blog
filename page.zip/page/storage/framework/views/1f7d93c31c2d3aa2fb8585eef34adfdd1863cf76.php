<?php $__env->startSection('title', __('laralum_dashboard::general.dashboard') ); ?>
<?php $__env->startSection('icon', "ion-speedometer"); ?>
<?php $__env->startSection('subtitle', __('laralum_dashboard::general.subtitle', ['name' => Auth::user()->name]) ); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_dashboard::general.home'); ?></a></li>
        <li><span href=""><?php echo app('translator')->getFromJson('laralum_dashboard::general.dashboard'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php 
        $user = \Laralum\Users\Models\User::findOrFail(Auth::id());
     ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(array_key_exists('permission', $widget)): ?>
                    <?php if($user->hasPermission($widget['permission']) or $user->superAdmin()): ?>
                        <div class="uk-width-1-1@m uk-width-1-2@l">
                            <div class="uk-card uk-card-default uk-card-body uk-height-1-1">
                                <?php echo view($widget['view']); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="uk-width-1-1@m uk-width-1-2@l">
                        <div class="uk-card uk-card-default uk-card-body uk-height-1-1">
                            <?php echo view($widget['view']); ?>

                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>