<?php $__env->startSection('icon', 'ion-eye'); ?>
<?php $__env->startSection('title', __('laralum_blog::general.view_post')); ?>
<?php $__env->startSection('subtitle', __('laralum_blog::general.view_post_desc', ['id' => $post->id])); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::blog.categories.index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::blog.categories.show', ['category' => $post->category->id])); ?>" ><?php echo app('translator')->getFromJson('laralum_blog::general.category_posts'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_blog::general.post_id', ['id' => $post->id]); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="uk-container">
    <div class="uk-child-width-1-1@s uk-grid-match" uk-grid>
    <div>
        <div class="uk-card-media-top">
            <img src="<?php echo e($post->image); ?>" alt="">
        </div>
        <div class="uk-card uk-card-default uk-card-body">
            <article class="uk-article">

                <h1 class="uk-article-title"><a class="uk-link-reset" href=""><?php echo e($post->title); ?></a></h1>
                <p class="uk-article-meta"><?php echo app('translator')->getFromJson('laralum_blog::general.written_by', ['username' => $post->user->name, 'time_ago' => $post->created_at->diffForHumans(), 'cat' => $post->category->name]); ?></p>

                <p><?php echo $post->content; ?></p>

                <br>
                <div class="uk-grid-small uk-child-width-1-1" uk-grid>
                    <span>
                        <a class="uk-button uk-button-text" href="#comments"><?php echo e(trans_choice('laralum_blog::general.comments_choice', $post->comments->count(), ['num' => $post->comments->count()])); ?></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                            <a class="uk-button uk-button-text uk-align-right" href="<?php echo e(route('laralum::blog.posts.destroy.confirm', ['post' => $post->id])); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.delete_post'); ?></a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $post)): ?>
                            <a class="uk-button uk-button-text uk-align-right" href="<?php echo e(route('laralum::blog.posts.edit', ['post' => $post->id])); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.edit_post'); ?></a>
                        <?php endif; ?>
                    </span>
                </div>

            </article>
        </div>
    </div>
    </div>
    <br><br><br>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access', \Laralum\Blog\Models\Comment::class)): ?>
        <div id="comments">
            <div class="uk-card uk-card-default uk-card-body">
                <h3 class="uk-card-title"><?php if($post->comments->count()): ?> <?php echo app('translator')->getFromJson('laralum_blog::general.comments'); ?> <?php else: ?> <?php echo app('translator')->getFromJson('laralum_blog::general.no_comments_yet'); ?> <?php endif; ?></h3>
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $comment)): ?>
                        <article class="uk-comment uk-comment-primary">
                            <header class="uk-comment-header uk-grid-medium uk-flex-middle" uk-grid>

                                <div class="uk-width-auto">
                                    <img class="uk-comment-avatar uk-border-circle" src="<?php echo e($comment->user->avatar()); ?>" width="80" height="80" alt="">
                                </div>
                                <div class="uk-width-expand">
                                    <h4 class="uk-comment-title uk-margin-remove"><span><?php echo e($comment->user->name); ?></span></h4>
                                    <ul class="uk-comment-meta uk-subnav uk-subnav-divider uk-margin-remove-top">
                                        <li><span><?php echo e($comment->created_at->diffForHumans()); ?></span></li>
                                    </ul>
                                </div>
                            </header>
                            <div class="uk-comment-body">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $comment)): ?>
                                    <a class="uk-button uk-button-text uk-align-right" href="<?php echo e(route('laralum::blog.comments.destroy.confirm',['comment' => $comment->id ])); ?>"><i style="font-size:18px;" class="icon ion-trash-b"></i> <?php echo app('translator')->getFromJson('laralum_blog::general.delete'); ?></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $comment)): ?>
                                    <button class="uk-button uk-button-text uk-align-right edit-comment-button" data-comment="<?php echo e($comment->comment); ?>" data-url="<?php echo e(route('laralum::blog.comments.update',['comment' => $comment->id ])); ?>"><i style="font-size:18px;" class="icon ion-edit"></i> <?php echo app('translator')->getFromJson('laralum_blog::general.edit'); ?></button>
                                <?php endif; ?>
                                <p class="comment"><?php echo e($comment->comment); ?></p>
                            </div>
                        </article>
                        <br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \Laralum\Blog\Models\Comment::class)): ?>
                <article class="uk-comment uk-comment-primary">
                    <header class="uk-comment-header uk-grid-medium uk-flex-middle" uk-grid>
                        <div class="uk-width-auto">
                            <img class="uk-comment-avatar uk-border-circle" src="<?php echo e(\Laralum\Users\Models\User::findOrFail(Auth::id())->avatar()); ?>" width="80" height="80" alt="">
                        </div>
                        <div class="uk-width-expand">
                            <h4 class="uk-comment-title uk-margin-remove"><span><?php echo e(\Laralum\Users\Models\User::findOrFail(Auth::id())->name); ?></span></h4>
                        </div>
                    </header>

                    <div class="uk-comment-body">

                        <form class="uk-form-stacked" method="POST" action="<?php echo e(route('laralum::blog.comments.store',['post' => $post->id])); ?>">
                            <?php echo e(csrf_field()); ?>

                            <fieldset class="uk-fieldset">
                                <div class="uk-margin">
                                    <textarea name="comment" class="uk-textarea" rows="8" placeholder="<?php echo e(__('laralum_blog::general.add_a_comment')); ?>"><?php echo e(old('comment')); ?></textarea>
                                </div>
                                <div class="uk-margin">
                                    <button type="submit" class="uk-button uk-button-primary">
                                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_blog::general.submit'); ?>
                                    </button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </article>
                <?php endif; ?>
            </div>
        </div>
        <form class="uk-form-stacked uk-hidden" id="edit-comment-form" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <fieldset class="uk-fieldset">
                <div class="uk-margin">
                    <textarea name="comment" class="uk-textarea" id="comment-textarea" rows="8" placeholder="<?php echo e(__('laralum_blog::general.edit_a_comment')); ?>"><?php echo e(old('comment')); ?></textarea>
                </div>
                <div class="uk-margin">
                    <button type="submit" class="uk-button uk-button-primary">
                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_blog::general.submit'); ?>
                    </button>
                </div>
            </fieldset>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('.edit-comment-button').click(function() {
                $('.edit-comment-button').prop('disabled', false);
                $(this).attr('disabled', 'disabled');
                var url = $(this).data('url');
                var comment = $(this).data('comment');
                $('#comment-textarea').html(comment);
                var form = $('#edit-comment-form').html();
                $('.edit-comment-form').hide();
                $('.comment').removeClass("uk-hidden"); 
                $(this).next().html('<form class="uk-form-stacked edit-comment-form uk-animation-scale-up" id="edit-comment-form" action="' + url + '" method="POST">' + form + '</form><p class="comment uk-hidden">'+comment+'</p>');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>