<?php $__env->startSection('icon', 'ion-plus-round'); ?>
<?php $__env->startSection('title', __('laralum_blog::general.create_category')); ?>
<?php $__env->startSection('subtitle', __('laralum_blog::general.create_category_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::blog.categories.index')); ?>"><?php echo app('translator')->getFromJson('laralum_blog::general.category_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_blog::general.create_category'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
            <div class="uk-width-1-1@s uk-width-3-5@l uk-width-1-3@xl">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo e(__('laralum_blog::general.create_category')); ?>

                    </div>
                    <div class="uk-card-body">
                        <form class="uk-form-stacked" method="POST" action="<?php echo e(route('laralum::blog.categories.store')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <fieldset class="uk-fieldset">


                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_blog::general.name'); ?></label>
                                    <div class="uk-form-controls">
                                        <input value="<?php echo e(old('name')); ?>" name="name" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_blog::general.name'); ?>">
                                    </div>
                                </div>

                                <div class="uk-margin">
                                    <button type="submit" class="uk-button uk-button-primary uk-align-right">
                                        <span class="ion-forward"></span>&nbsp; <?php echo e(__('laralum_blog::general.create_category')); ?>

                                    </button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>