<?php $__env->startSection('icon', 'ion-ribbon-b'); ?>
<?php $__env->startSection('title', __('laralum_roles::general.role_list')); ?>
<?php $__env->startSection('subtitle', __('laralum_roles::general.roles_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_roles::general.home'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_roles::general.role_list'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid class="uk-child-width-1-1">
            <div>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_roles::general.role_list'); ?>
                    </div>
                    <div class="uk-card-body">
                        <div class="uk-overflow-auto">
                            <table class="uk-table uk-table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo app('translator')->getFromJson('laralum_roles::general.name'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('laralum_roles::general.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($role->id); ?></td>
                                            <td style="color:<?php echo e($role->color); ?>"><?php echo e($role->name); ?></td>
                                            <td class="uk-table-shrink">
                                                <div class="uk-button-group">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $role)): ?>
                                                        <a href="<?php echo e(route('laralum::roles.edit', ['id' => $role->id])); ?>" class="uk-button uk-button-small uk-button-default">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.edit'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled="disabled" class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.edit'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $role)): ?>
                                                        <a href="<?php echo e(route('laralum::roles.permissions', ['id' => $role->id])); ?>" class="uk-button uk-button-small uk-button-default">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.permissions'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled="disabled" class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.permissions'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $role)): ?>
                                                        <a href="<?php echo e(route('laralum::roles.destroy.confirm', ['ticket' => $role->id])); ?>" class="uk-button uk-button-small uk-button-danger">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.delete'); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <button disabled="disabled" class="uk-button uk-button-small uk-button-default uk-disabled">
                                                            <?php echo app('translator')->getFromJson('laralum_roles::general.delete'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo $__env->make('laralum::layouts.pagination', ['paginator' => $roles], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>