<?php $__env->startSection('icon', 'ion-person-add'); ?>
<?php $__env->startSection('title', __('laralum_users::general.create_user')); ?>
<?php $__env->startSection('subtitle', __('laralum_users::general.create_user_desc')); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_users::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::users.index')); ?>"><?php echo app('translator')->getFromJson('laralum_users::general.user_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_users::general.create_user'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
        <div uk-grid>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
            <div class="uk-width-1-1@s uk-width-3-5@l uk-width-1-3@xl">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_users::general.create_user'); ?>
                    </div>
                    <div class="uk-card-body">
                        <form method="POST" action="<?php echo e(route('laralum::users.store')); ?>" class="uk-form-stacked">
                            <?php echo e(csrf_field()); ?>

                            <fieldset class="uk-fieldset">
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_users::general.name'); ?></label>
                                    <input value="<?php echo e(old('name')); ?>" name="name" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_users::general.name'); ?>">
                                </div>

                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_users::general.email'); ?></label>
                                    <input value="<?php echo e(old('email')); ?>" name="email" class="uk-input" type="email" placeholder="<?php echo app('translator')->getFromJson('laralum_users::general.email'); ?>">
                                </div>

                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_users::general.password'); ?></label>
                                    <input name="password" class="uk-input" type="password" placeholder="<?php echo app('translator')->getFromJson('laralum_users::general.password'); ?>">
                                </div>

                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_users::general.password_confirmation'); ?></label>
                                    <input name="password_confirmation" class="uk-input" type="password" placeholder="<?php echo app('translator')->getFromJson('laralum_users::general.password_confirmation'); ?>">
                                </div>
                                <div class="uk-margin">
                                    <a href="<?php echo e(route('laralum::users.index')); ?>" class="uk-align-left uk-button uk-button-default"><?php echo app('translator')->getFromJson('laralum_users::general.cancel'); ?></a>
                                    <button type="submit" class="uk-button uk-button-primary uk-align-right">
                                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_users::general.create'); ?>
                                    </button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>