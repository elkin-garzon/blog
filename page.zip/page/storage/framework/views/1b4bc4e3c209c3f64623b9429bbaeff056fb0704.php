<?php $__env->startSection('icon', 'ion-edit'); ?>
<?php $__env->startSection('title', __('laralum_roles::general.edit_role')); ?>
<?php $__env->startSection('subtitle', __('laralum_roles::general.edit_desc', ['id' => $role->id, 'time_ago' => $role->created_at->diffForHumans()])); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="uk-breadcrumb">
        <li><a href="<?php echo e(route('laralum::index')); ?>"><?php echo app('translator')->getFromJson('laralum_roles::general.home'); ?></a></li>
        <li><a href="<?php echo e(route('laralum::roles.index')); ?>"><?php echo app('translator')->getFromJson('laralum_roles::general.role_list'); ?></a></li>
        <li><span><?php echo app('translator')->getFromJson('laralum_roles::general.create_role'); ?></span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-container uk-container-large">
    <div uk-grid>
        <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
            <div class="uk-width-1-1@s uk-width-3-5@l uk-width-1-3@xl">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header">
                        <?php echo app('translator')->getFromJson('laralum_roles::general.edit_role', ['id' => $role->id]); ?>
                    </div>
                    <div class="uk-card-body">
                        <form method="POST" action="<?php echo e(route('laralum::roles.update', ['role' => $role])); ?>" class="uk-form-stacked">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <fieldset class="uk-fieldset">
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_roles::general.name'); ?></label>
                                    <input value="<?php echo e(old('name', $role->name)); ?>" name="name" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_roles::general.name'); ?>">
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_roles::general.color'); ?></label>
                                    <input value="<?php echo e(old('color', isset($role) ? $role->color : '')); ?>" name="color" class="uk-input" type="text" placeholder="<?php echo app('translator')->getFromJson('laralum_roles::general.color'); ?>">
                                </div>
                                <div class="uk-margin">
                                    <label class="uk-form-label"><?php echo app('translator')->getFromJson('laralum_roles::general.description'); ?></label>
                                    <div class="uk-form-controls">
                                        <textarea name="description" class="uk-textarea" rows="5" placeholder="<?php echo e(__('laralum_roles::general.description')); ?>"><?php echo e(old('description', isset($role) ? $role->description : '')); ?></textarea>
                                    </div>
                                </div>
                                <div class="uk-margin">
                                    <a href="<?php echo e(route('laralum::roles.index')); ?>" class="uk-align-left uk-button uk-button-default"><?php echo app('translator')->getFromJson('laralum_roles::general.cancel'); ?></a>
                                    <button type="submit" class="uk-button uk-button-primary uk-align-right">
                                        <span class="ion-forward"></span>&nbsp; <?php echo app('translator')->getFromJson('laralum_roles::general.edit'); ?>
                                    </button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1@s uk-width-1-5@l uk-width-1-3@xl"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laralum::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>